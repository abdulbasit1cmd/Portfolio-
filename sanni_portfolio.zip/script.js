// Future interactive features go here
console.log("Portfolio loaded!");
